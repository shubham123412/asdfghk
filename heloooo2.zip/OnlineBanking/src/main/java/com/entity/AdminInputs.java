package com.entity;

import java.time.LocalDateTime;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

@Entity
@Table(name="admininputs")
public class AdminInputs {
	
@Id
private long ReferenceId ;

@Temporal(TemporalType.DATE)
private Date AporovalDate;

public AdminInputs(long referenceId, Date aporovalDate, String aPPROVAL, String aCCOUNT_NO, String aDMIN_REMARKS) {
	super();
	ReferenceId = referenceId;
	AporovalDate = aporovalDate;
	APPROVAL = aPPROVAL;
	ACCOUNT_NO = aCCOUNT_NO;
	ADMIN_REMARKS = aDMIN_REMARKS;
}
public long getReferenceId() {
	return ReferenceId;
}
public void setReferenceId(long referenceId) {
	ReferenceId = referenceId;
}
public Date getAporovalDate() {
	return AporovalDate;
}
public void setAporovalDate(Date aporovalDate) {
	AporovalDate = aporovalDate;
}
public String getAPPROVAL() {
	return APPROVAL;
}
public void setAPPROVAL(String aPPROVAL) {
	APPROVAL = aPPROVAL;
}
public String getACCOUNT_NO() {
	return ACCOUNT_NO;
}
public void setACCOUNT_NO(String aCCOUNT_NO) {
	ACCOUNT_NO = aCCOUNT_NO;
}
public String getADMIN_REMARKS() {
	return ADMIN_REMARKS;
}
public void setADMIN_REMARKS(String aDMIN_REMARKS) {
	ADMIN_REMARKS = aDMIN_REMARKS;
}
@Column
private  String APPROVAL;
@Column
private  String ACCOUNT_NO;
@Column
private  String ADMIN_REMARKS;

}

