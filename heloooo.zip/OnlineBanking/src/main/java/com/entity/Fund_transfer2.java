package com.entity;

import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;

@Entity
public class Fund_transfer2 {
	


@OneToMany(cascade=CascadeType.ALL, fetch = FetchType.EAGER)
@JoinColumn(name="AccountNo")
private Set<PayeeDetails> PayeeDetails1;

//private long AccountNo;

private int Amount;

@OneToMany(cascade=CascadeType.ALL, fetch = FetchType.EAGER)
@JoinColumn(name="PayeeAccountNo")
private Set<PayeeDetails> PayeeDetails2;

//private long PayeeAccountNo ;

//public long getAccountNo() {
//	return AccountNo;
//}

//public void setAccountNo(long accountNo) {
//	AccountNo = accountNo;
//}

public int getAmount() {
	return Amount;
}

public void setAmount(int amount) {
	Amount = amount;
}

//public long getPayeeAccountNo() {
//	return PayeeAccountNo;
//}

//public void setPayeeAccountNo(long payeeAccountNo) {
//	PayeeAccountNo = payeeAccountNo;
//}

public int getTransactionID() {
	return TransactionID;
}

public void setTransactionID(int transactionID) {
	TransactionID = transactionID;
}

public String getDatee() {
	return Datee;
}

public void setDatee(String datee) {
	Datee = datee;
}

public String getTransactionMode() {
	return TransactionMode;
}

public void setTransactionMode(String transactionMode) {
	TransactionMode = transactionMode;
}

public String getTransactionType() {
	return TransactionType;
}

public void setTransactionType(String transactionType) {
	TransactionType = transactionType;
}

public String getTransaction_Remarks() {
	return Transaction_Remarks;
}

public void setTransaction_Remarks(String transaction_Remarks) {
	Transaction_Remarks = transaction_Remarks;
}


public Fund_transfer2() {
	super();
	// TODO Auto-generated constructor stub
}


@Id
@GeneratedValue(strategy = GenerationType.AUTO)
private int TransactionID ;

private String Datee;

private String TransactionMode;

private String TransactionType; 

private String Transaction_Remarks; 

//foreign key (PayeeAccountNo,AccountNo) references PayeeDetails(PayeeAccountNo,AccountNo));


}