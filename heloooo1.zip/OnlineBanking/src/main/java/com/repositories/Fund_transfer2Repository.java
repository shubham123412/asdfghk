package com.repositories;

public interface Fund_transfer2Repository {

}
