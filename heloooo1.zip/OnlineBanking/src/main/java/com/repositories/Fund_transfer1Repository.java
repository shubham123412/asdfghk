package com.repositories;

public interface Fund_transfer1Repository {

}
