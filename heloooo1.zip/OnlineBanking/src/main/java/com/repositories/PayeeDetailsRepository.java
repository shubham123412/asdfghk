package com.repositories;

public interface PayeeDetailsRepository {

}
