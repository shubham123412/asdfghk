package com.entity;


import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

//import com.entity.logininputs;

@Entity
@Table(name="regsiternetbank")
public class Register {
	
	@OneToOne(cascade=CascadeType.ALL, fetch = FetchType.EAGER)
	@JoinColumn(name="referenecid")
	private Set<Login> logininputs;
	
	@Column(name="referenceid")
	private int ReferenceId;
	
	@Column(name="AccountNo")
	private long accountno;
	@Id
	@Column(name="User_Id")
	private int userid;
	
	@Column(name="Login_Password")
	private String loginpassword;
	
	@Column(name="Transaction_password")
	private String transactionpassword;
	
	public int getReferenceId() {
		return ReferenceId;
	}
	public void setReferenceId(int referenceId) {
		ReferenceId = referenceId;
	}
	public long getAccountno() {
		return accountno;
	}
	public void setAccountno(long accountno) {
		this.accountno = accountno;
	}
	public int getUserid() {
		return userid;
	}
	public void setUserid(int userid) {
		this.userid = userid;
	}
	public String getLoginpassword() {
		return loginpassword;
	}
	public void setLoginpassword(String loginpassword) {
		this.loginpassword = loginpassword;
	}
	public String getTransactionpassword() {
		return transactionpassword;
	}
	public void setTransactionpassword(String transactionpassword) {
		this.transactionpassword = transactionpassword;
	}
	
	public Register() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
}
	
