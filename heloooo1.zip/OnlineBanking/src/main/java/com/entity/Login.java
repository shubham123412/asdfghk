package com.entity;

import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;


@Entity
@Table(name="Login_details")
public class Login {
	
	
	public Login() {
		super();
		// TODO Auto-generated constructor stub
	}
	@OneToOne(cascade=CascadeType.ALL, fetch = FetchType.EAGER)
	@JoinColumn(name="user_id")
	private Set<Register> register;
	
	@Id
	@Column(name="AccountNo")
	private long accno;
	
	
	private int user_id;
	
	@Column(name="Transaction_Password")
	private String TransactionPass;
	
	@Column(name="login_Password")
	private String Loginpass;
		
	@Column(name="Reference_id")
	private int reference_id;
	
	public long getAccno() {
		return accno;
	}
	public void setAccno(long accno) {
		this.accno = accno;
	}
	public int getUser_id() {
		return user_id;
	}
	public void setUser_id(int userid) {
		this.user_id = userid;
	}
	public String getTransactionPass() {
		return TransactionPass;
	}
	public void setTransactionPass(String transactionPass) {
		TransactionPass = transactionPass;
	}
	public String getLoginpass() {
		return Loginpass;
	}
	public void setLoginpass(String loginpass) {
		Loginpass = loginpass;
	}
	public int getReference_id() {
		return reference_id;
	}
	public void setReference_id(int reference_id) {
		this.reference_id = reference_id;
	}

	
	
}

