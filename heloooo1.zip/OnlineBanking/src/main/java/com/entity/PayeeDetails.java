package com.entity;

import javax.persistence.CascadeType;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

@Entity
public class PayeeDetails {
	
	
@EmbeddedId
private PayeeDetailsEmbedded PayeeDetailsEmbedded;


private String PayeeName;


public PayeeDetailsEmbedded getPayeeDetailsEmbedded() {
	return PayeeDetailsEmbedded;
}


public void setPayeeDetailsEmbedded(PayeeDetailsEmbedded payeeDetailsEmbedded) {
	PayeeDetailsEmbedded = payeeDetailsEmbedded;
}


public String getPayeeName() {
	return PayeeName;
}


public void setPayeeName(String payeeName) {
	PayeeName = payeeName;
}




public PayeeDetails(com.entity.PayeeDetailsEmbedded payeeDetailsEmbedded, String payeeName, int user_Id) {
	super();
	PayeeDetailsEmbedded = payeeDetailsEmbedded;
	PayeeName = payeeName;
//	User_Id = user_Id;
}




//@Id
//private long PayeeAccountNo;


@OneToOne(cascade=CascadeType.ALL,fetch = FetchType.EAGER )
@JoinColumn(name = "user_id", nullable = false)
private Register registernetbank;
private int User_Id ;


//	public int getUser_Id() {
//		return User_Id;
//	}


//	public void setUser_Id(int user_Id) {
//		User_Id = user_Id;
//	}
	
//	Primary key (AccountNo,PayeeAccountNo),
//	foreign key (user_id) references registernetbank(User_Id)
	
}
