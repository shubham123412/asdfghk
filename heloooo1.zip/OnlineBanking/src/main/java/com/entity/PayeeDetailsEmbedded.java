package com.entity;

import javax.persistence.Embeddable;

@Embeddable
public class PayeeDetailsEmbedded {
	
	private long AccountNo;
	private long PayeeAccountNo;
	
	
	public PayeeDetailsEmbedded(long accountNo, long payeeAccountNo) {
		super();
		AccountNo = accountNo;
		PayeeAccountNo = payeeAccountNo;
	}
	public long getAccountNo() {
		return AccountNo;
	}
	public void setAccountNo(long accountNo) {
		AccountNo = accountNo;
	}
	public long getPayeeAccountNo() {
		return PayeeAccountNo;
	}
	public void setPayeeAccountNo(long payeeAccountNo) {
		PayeeAccountNo = payeeAccountNo;
	}
	

}
